import cv2
import time
import numpy as np
from classePixelimg import Image
import random

#conversion de la matrice de la webcam à pixel image
def image_to_cv2(img):
    mat = []
    for ligne in img.matrice:
        image = []
        for pixel in ligne:
            r,v,b,a = pixel.get_couleur()
            image.append([b,v,r])  # RGB -> BGR
        mat.append(image)
    return np.array(mat, dtype=np.uint8)


#initialisation de la taille de la capture webcam
capture = cv2.VideoCapture(0, cv2.CAP_DSHOW)
capture.set(cv2.CAP_PROP_FRAME_WIDTH,1280)
capture.set(cv2.CAP_PROP_FRAME_HEIGHT,768)

cv2.namedWindow("Projet", cv2.WINDOW_NORMAL)
cv2.setWindowProperty("Projet", cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

visage = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml' #model IA de visage à détecter
)

#variable timer pour prise de capture
timer_actif = False
affichage_actif = False
depart = 0
image_affichee = None
temps_affichage = 0
VISAGE = None

while True:

    ret, frame = capture.read() #commencement de la capture
    frame = cv2.flip(frame, 1) #miroir
    if not ret:
        break

    frame = cv2.resize(frame, (1280,768))

    gris = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    visages = visage.detectMultiScale(gris,1.3,5)

    # garder dernier visage
    if len(visages) > 0:
        VISAGE = visages[0]

    min = 300

    if VISAGE is not None:
        x,y,l,h = VISAGE
        face = frame[y:y+h, x:x+l]

        if l > min:
            if VISAGE is not None and not timer_actif and not affichage_actif:
                timer_actif = True #lancement du compteur
                depart = time.time()
                print("visage détecté, capture dans 3 secondes")
        else:
            timer_actif = False


    # CAPTURE de l'image
    if timer_actif and time.time() - depart >= 3:

        if VISAGE is None:
            timer_actif = False
            continue



        face = cv2.resize(face,(250,250)) #coupure de la matrice sur l'image

        # creation de l'image pixel
        img = Image((1280,768))

        # fond blanc
        for Y in range(0, img.hauteur, 5):
            for X in range(0, img.largeur, 5):

                r = random.randint(0,255)
                g = random.randint(0,255)
                b = random.randint(0,255)

                for dy in range(5):
                    for dx in range(5):

                        if X + dx < img.largeur and Y + dy < img.hauteur:
                            img.set_couleur((X + dx, Y + dy), (r, g, b))

        # colle le visage
        px = 515
        py = 80

        for i in range(250):
            for j in range(250):
                b,g,r = face[i][j]
                img.set_couleur((px+j,py+i),(r,g,b))

        # corp
        for y1 in range(330,600):
            for x1 in range(630,650):
                img.set_couleur((x1,y1),(0,0,0))

        # bras
        for x1 in range(450,630):
            for y1 in range(400,420):
                img.set_couleur((x1,y1),(0,0,0))

        for x1 in range(650,830):
            for y1 in range(400,420):
                img.set_couleur((x1,y1),(0,0,0))

        # jambes
        for x1 in range(600,630):
            for y1 in range(600,740):
                img.set_couleur((x1,y1),(0,0,0))

        for x1 in range(650,680):
            for y1 in range(600,740):
                img.set_couleur((x1,y1),(0,0,0))

        image_affichee = image_to_cv2(img)

        affichage_actif = True
        temps_affichage = time.time()
        timer_actif = False

    # affiche le resultat
    if affichage_actif:

        cv2.imshow("Projet", image_affichee)
        timer_actif = True

        if timer_actif and time.time() - depart >= 15:
            affichage_actif = False
            timer_actif = False

    else:
        cv2.imshow("Projet", frame)

    if cv2.waitKey(1) == ord('q'):
        break

capture.release()
cv2.destroyAllWindows()