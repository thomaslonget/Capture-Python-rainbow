﻿# Créé par prof, le 18/10/2025 en Python 3.4
# Coding utf-8

from random import randint

class Pixel():
    def __init__(self,position:tuple,couleur:tuple = (255,255,255,255)):
        self.x = position[0]
        self.y = position[1]
        self.r = couleur[0]
        self.v = couleur[1]
        self.b = couleur[2]
        if len(couleur)== 4:
            self.alpha = couleur[3]
        else:
            self.alpha = 255 # pixel opaque par défaut


    def __str__(self):
        return str(self.r)+","+str(self.v)+","+str(self.b)+","+str(self.alpha)


    def get_position(self):
        return self.x, self.y


    def get_couleur(self):
        return self.r, self.v, self.b, self.alpha


    def set_couleur(self,couleur:tuple):
        self.r = couleur[0]
        self.v = couleur[1]
        self.b = couleur[2]
        if len(couleur)== 4:
            self.alpha = couleur[3]
        else:
            self.alpha = 255 # pixel opaque


class Image():
    def __init__(self,dimensions:tuple=(640,480)):
        self.matrice = [[Pixel((x,y)) for x in range(dimensions[0])]for y in range(dimensions[1])]
        self.largeur = len(self.matrice[0]) # nombre de pixels par ligne
        self.hauteur = len(self.matrice) # nombre de lignes


    def affiche_matrice(self):
        for ligne in self.matrice:
            print([pixel.get_couleur() for pixel in ligne])


    def get_taille(self):
        return dimensions[0, dimensions[1]]


    def get_couleur(self,position:tuple):
        # appelle l'accesseur du pixel à la position
        return self.matrice[position[1]][position[0]].get_couleur()


    def set_couleur(self,position:tuple,couleur:tuple):
        # appelle l'accesseur du pixel à la position
        self.matrice[position[1]][position[0]].set_couleur(couleur)


    def sauvegarde(self,nom="image"):
        from cv2 import imwrite
        from numpy import array
        mat = [[pixel.get_couleur() for pixel in ligne]for ligne in self.matrice]
        m = array(mat)
        imwrite(nom+".png",m)


img = Image((200,300))
for y in range(img.hauteur):
    for x in range(img.largeur):
        r,v,b,a = img.get_couleur((x,y))

        # si pixel blanc (silhouette)
        if r == 255 and v == 255 and b == 255:
            if randint(0,4) == 0:  # 1 pixel sur 5 disparaît
                img.set_couleur((x,y),(30,30,30))

# fond gris


# tête (cercle)
cx, cy, r = 100, 60, 30
for y in range(img.hauteur):
    for x in range(img.largeur):
        if abs((x-cx)**2 + (y-cy)**2 - r**2) < 50:
            img.set_couleur((x,y),(0,0,0))

# corps (rectangle)
for y in range(100,220):
    img.set_couleur((85,y),(0,0,0))
    img.set_couleur((115,y),(0,0,0))




